import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Printer, ArrowLeft, QrCode, Droplets, Wrench, History, Download } from "lucide-react"
import InkRefillForm from "@/components/ink-refill-form"
import MaintenanceForm from "@/components/maintenance-form"
import PrinterHistory from "@/components/printer-history"
import PrinterQRCode from "@/components/printer-qr-code"

export default function PrinterPage({ params }: { params: { id: string } }) {
  // This would normally fetch printer data based on the ID
  const printer = {
    id: params.id,
    model: "L3210",
    serial: "INV1234567",
    location: "Sala Administrativo",
    responsible: "Assistente Administrativo",
    status: "active",
    warranty: "2025-12-31",
    notes: "",
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
        <div className="flex flex-1 items-center gap-2">
          <Printer className="h-6 w-6" />
          <h1 className="text-lg font-semibold">LOJA CONSTROI - Controle de Impressoras</h1>
        </div>
      </header>
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-1">
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
          </Link>
          <div className="ml-auto">
            <Button variant="outline" size="sm" className="gap-1 mr-2">
              <Download className="h-4 w-4" />
              Exportar Histórico
            </Button>
            <Button variant="outline" size="sm" className="gap-1">
              <QrCode className="h-4 w-4" />
              Imprimir QR Code
            </Button>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-[1fr_300px]">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{printer.model}</CardTitle>
                    <CardDescription>
                      {printer.location} - {printer.responsible}
                    </CardDescription>
                  </div>
                  <Badge variant="outline" className="ml-auto">
                    {printer.status === "active"
                      ? "Ativa"
                      : printer.status === "maintenance"
                        ? "Em Manutenção"
                        : printer.status === "warranty"
                          ? "Em Garantia"
                          : "Inativa"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium">Número de Série</p>
                    <p className="text-sm text-muted-foreground">{printer.serial}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Garantia até</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(printer.warranty).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Tabs defaultValue="abastecer">
              <TabsList className="grid grid-cols-3">
                <TabsTrigger value="abastecer">
                  <Droplets className="mr-2 h-4 w-4" />
                  Abastecer
                </TabsTrigger>
                <TabsTrigger value="manutencao">
                  <Wrench className="mr-2 h-4 w-4" />
                  Manutenção
                </TabsTrigger>
                <TabsTrigger value="historico">
                  <History className="mr-2 h-4 w-4" />
                  Histórico
                </TabsTrigger>
              </TabsList>
              <TabsContent value="abastecer" className="space-y-4">
                <InkRefillForm printerId={printer.id} />
              </TabsContent>
              <TabsContent value="manutencao" className="space-y-4">
                <MaintenanceForm printerId={printer.id} />
              </TabsContent>
              <TabsContent value="historico" className="space-y-4">
                <PrinterHistory printerId={printer.id} />
              </TabsContent>
            </Tabs>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle>QR Code</CardTitle>
                <CardDescription>Escaneie para acessar esta impressora</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <PrinterQRCode printerId={printer.id} />
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  <Download className="mr-2 h-4 w-4" />
                  Baixar QR Code
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

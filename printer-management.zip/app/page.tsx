import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Printer, History, Droplets, Wrench, Plus } from "lucide-react"
import PrinterList from "@/components/printer-list"
import RecentActivity from "@/components/recent-activity"
import MonthlyUsageChart from "@/components/monthly-usage-chart"

export default function Dashboard() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
        <div className="flex flex-1 items-center gap-2">
          <Printer className="h-6 w-6" />
          <h1 className="text-lg font-semibold">LOJA CONSTROI - Controle de Impressoras</h1>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/add-printer">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Nova Impressora
            </Button>
          </Link>
        </div>
      </header>
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Impressoras</CardTitle>
              <Printer className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">24</div>
              <p className="text-xs text-muted-foreground">4 em manutenção</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Abastecimentos este mês</CardTitle>
              <Droplets className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">36</div>
              <p className="text-xs text-muted-foreground">+12% em relação ao mês anterior</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Manutenções este mês</CardTitle>
              <Wrench className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">8</div>
              <p className="text-xs text-muted-foreground">-3% em relação ao mês anterior</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Histórico de Atividades</CardTitle>
              <History className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">128</div>
              <p className="text-xs text-muted-foreground">Registros nos últimos 30 dias</p>
            </CardContent>
          </Card>
        </div>
        <Tabs defaultValue="impressoras">
          <TabsList>
            <TabsTrigger value="impressoras">Impressoras</TabsTrigger>
            <TabsTrigger value="atividades">Atividades Recentes</TabsTrigger>
            <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
          </TabsList>
          <TabsContent value="impressoras" className="space-y-4">
            <PrinterList />
          </TabsContent>
          <TabsContent value="atividades" className="space-y-4">
            <RecentActivity />
          </TabsContent>
          <TabsContent value="relatorios" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Consumo Mensal de Tinta</CardTitle>
                <CardDescription>Visualize o consumo de tinta por cor e por impressora</CardDescription>
              </CardHeader>
              <CardContent>
                <MonthlyUsageChart />
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Exportar para Excel
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

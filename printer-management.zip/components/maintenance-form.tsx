"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePicker } from "@/components/date-picker"

export default function MaintenanceForm({ printerId }: { printerId: string }) {
  const [maintenanceDate, setMaintenanceDate] = useState<Date | undefined>(new Date())

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would save the maintenance data
    console.log({
      printerId,
      maintenanceDate,
      // other form data
    })
    // Reset form or show success message
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Registrar Manutenção</CardTitle>
        <CardDescription>Registre detalhes da manutenção realizada</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Data da Manutenção</Label>
            <DatePicker date={maintenanceDate} setDate={setMaintenanceDate} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">Tipo de Manutenção</Label>
            <Select>
              <SelectTrigger id="type">
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="preventive">Preventiva</SelectItem>
                <SelectItem value="corrective">Corretiva</SelectItem>
                <SelectItem value="cleaning">Limpeza</SelectItem>
                <SelectItem value="parts">Troca de Peças</SelectItem>
                <SelectItem value="other">Outro</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrição da Manutenção</Label>
            <Textarea id="description" placeholder="Descreva detalhadamente o que foi feito na manutenção" rows={4} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="technician">Técnico Responsável</Label>
            <Input id="technician" placeholder="Nome do técnico" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="cost">Custo (R$)</Label>
            <Input id="cost" type="number" placeholder="0,00" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Novo Status da Impressora</Label>
            <Select>
              <SelectTrigger id="status">
                <SelectValue placeholder="Selecione o status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Ativa</SelectItem>
                <SelectItem value="maintenance">Continua em Manutenção</SelectItem>
                <SelectItem value="warranty">Em Garantia</SelectItem>
                <SelectItem value="inactive">Inativa</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full">
            Registrar Manutenção
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Droplets, Wrench } from "lucide-react"

export default function PrinterHistory({ printerId }: { printerId: string }) {
  // This would normally fetch history from a database or API
  const history = [
    {
      id: "1",
      type: "refill",
      date: "2025-04-05",
      details: "Preto: 50ml, Amarelo: 20ml",
      user: "João Silva",
    },
    {
      id: "2",
      type: "maintenance",
      date: "2025-03-20",
      details: "Limpeza de cabeçote",
      user: "Maria Oliveira",
    },
    {
      id: "3",
      type: "refill",
      date: "2025-03-15",
      details: "Preto: 30ml, Azul: 15ml",
      user: "João Silva",
    },
    {
      id: "4",
      type: "maintenance",
      date: "2025-02-28",
      details: "Troca de mangueira de tinta",
      user: "Técnico Externo",
    },
    {
      id: "5",
      type: "refill",
      date: "2025-02-22",
      details: "Preto: 50ml, Rosa: 25ml, Azul: 25ml",
      user: "João Silva",
    },
  ]

  return (
    <Card>
      <CardContent className="p-6">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Data</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Detalhes</TableHead>
              <TableHead>Usuário</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {history.map((item) => (
              <TableRow key={item.id}>
                <TableCell>{new Date(item.date).toLocaleDateString("pt-BR")}</TableCell>
                <TableCell>
                  <Badge variant={item.type === "refill" ? "default" : "outline"} className="flex items-center gap-1">
                    {item.type === "refill" ? (
                      <>
                        <Droplets className="h-3 w-3" />
                        Abastecimento
                      </>
                    ) : (
                      <>
                        <Wrench className="h-3 w-3" />
                        Manutenção
                      </>
                    )}
                  </Badge>
                </TableCell>
                <TableCell>{item.details}</TableCell>
                <TableCell>{item.user}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

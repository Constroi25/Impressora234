"use client"

import { useEffect, useState } from "react"
import QRCode from "qrcode.react"

export default function PrinterQRCode({ printerId }: { printerId: string }) {
  const [url, setUrl] = useState("")

  useEffect(() => {
    // In a real app, this would be your deployed URL
    const baseUrl = window.location.origin
    setUrl(`${baseUrl}/printer/${printerId}`)
  }, [printerId])

  return (
    <div className="bg-white p-4 rounded-lg">
      {url ? (
        <QRCode value={url} size={200} level="H" includeMargin={true} />
      ) : (
        <div className="w-[200px] h-[200px] flex items-center justify-center bg-muted">Carregando...</div>
      )}
    </div>
  )
}

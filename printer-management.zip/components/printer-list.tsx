import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Printer, Search, QrCode } from "lucide-react"

export default function PrinterList() {
  // This would normally come from a database or API
  const printers = [
    {
      id: "1",
      model: "L3210",
      location: "Sala Administrativo",
      responsible: "Assistente Administrativo",
      status: "active",
      lastRefill: "2025-04-05",
    },
    {
      id: "2",
      model: "L1250",
      location: "Sala Administrativo",
      responsible: "Aux. Administrativo",
      status: "active",
      lastRefill: "2025-04-05",
    },
    {
      id: "3",
      model: "L4260",
      location: "Financeiro",
      responsible: "Contador",
      status: "maintenance",
      lastRefill: "2025-03-29",
    },
    {
      id: "4",
      model: "L3150",
      location: "Recursos Humanos",
      responsible: "Analista de RH",
      status: "warranty",
      lastRefill: "2025-04-01",
    },
    {
      id: "5",
      model: "L355",
      location: "Recepção",
      responsible: "Recepcionista",
      status: "active",
      lastRefill: "2025-04-05",
    },
  ]

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input type="search" placeholder="Buscar impressoras..." className="w-full pl-8" />
          </div>
          <Button variant="outline" size="sm">
            Filtrar
          </Button>
        </div>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Modelo</TableHead>
                <TableHead>Localização</TableHead>
                <TableHead>Responsável</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Último Abastecimento</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {printers.map((printer) => (
                <TableRow key={printer.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <Printer className="h-4 w-4 text-muted-foreground" />
                      {printer.model}
                    </div>
                  </TableCell>
                  <TableCell>{printer.location}</TableCell>
                  <TableCell>{printer.responsible}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        printer.status === "active"
                          ? "default"
                          : printer.status === "maintenance"
                            ? "destructive"
                            : printer.status === "warranty"
                              ? "outline"
                              : "secondary"
                      }
                    >
                      {printer.status === "active"
                        ? "Ativa"
                        : printer.status === "maintenance"
                          ? "Em Manutenção"
                          : printer.status === "warranty"
                            ? "Em Garantia"
                            : "Inativa"}
                    </Badge>
                  </TableCell>
                  <TableCell>{new Date(printer.lastRefill).toLocaleDateString("pt-BR")}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" asChild>
                        <Link href={`/printer/${printer.id}`}>
                          <QrCode className="h-4 w-4" />
                          <span className="sr-only">QR Code</span>
                        </Link>
                      </Button>
                      <Button variant="ghost" size="icon" asChild>
                        <Link href={`/printer/${printer.id}`}>
                          <span>Ver</span>
                        </Link>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

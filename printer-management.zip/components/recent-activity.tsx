import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Printer, Droplets, Wrench } from "lucide-react"

export default function RecentActivity() {
  // This would normally fetch from a database or API
  const activities = [
    {
      id: "1",
      type: "refill",
      date: "2025-04-05",
      printer: "L3210",
      location: "Sala Administrativo",
      details: "Preto: 50ml, Amarelo: 20ml",
      user: "João Silva",
    },
    {
      id: "2",
      type: "maintenance",
      date: "2025-04-03",
      printer: "L4260",
      location: "Financeiro",
      details: "Limpeza de cabeçote",
      user: "Maria Oliveira",
    },
    {
      id: "3",
      type: "refill",
      date: "2025-04-01",
      printer: "L3150",
      location: "Recursos Humanos",
      details: "Preto: 30ml, Azul: 15ml",
      user: "João Silva",
    },
    {
      id: "4",
      type: "maintenance",
      date: "2025-03-28",
      printer: "L3210",
      location: "Sala Administrativo",
      details: "Troca de mangueira de tinta",
      user: "Técnico Externo",
    },
    {
      id: "5",
      type: "refill",
      date: "2025-03-25",
      printer: "L355",
      location: "Recepção",
      details: "Preto: 50ml, Rosa: 25ml, Azul: 25ml",
      user: "João Silva",
    },
  ]

  return (
    <Card>
      <CardContent className="p-6">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Data</TableHead>
              <TableHead>Impressora</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Detalhes</TableHead>
              <TableHead>Usuário</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {activities.map((activity) => (
              <TableRow key={activity.id}>
                <TableCell>{new Date(activity.date).toLocaleDateString("pt-BR")}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Printer className="h-4 w-4 text-muted-foreground" />
                    <span>{activity.printer}</span>
                    <span className="text-xs text-muted-foreground">({activity.location})</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge
                    variant={activity.type === "refill" ? "default" : "outline"}
                    className="flex items-center gap-1"
                  >
                    {activity.type === "refill" ? (
                      <>
                        <Droplets className="h-3 w-3" />
                        Abastecimento
                      </>
                    ) : (
                      <>
                        <Wrench className="h-3 w-3" />
                        Manutenção
                      </>
                    )}
                  </Badge>
                </TableCell>
                <TableCell>{activity.details}</TableCell>
                <TableCell>{activity.user}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { DatePicker } from "@/components/date-picker"

export default function InkRefillForm({ printerId }: { printerId: string }) {
  const [refillDate, setRefillDate] = useState<Date | undefined>(new Date())
  const [colors, setColors] = useState({
    black: { checked: false, amount: "" },
    yellow: { checked: false, amount: "" },
    pink: { checked: false, amount: "" },
    blue: { checked: false, amount: "" },
  })

  const handleColorCheck = (color: keyof typeof colors) => {
    setColors({
      ...colors,
      [color]: {
        ...colors[color],
        checked: !colors[color].checked,
      },
    })
  }

  const handleAmountChange = (color: keyof typeof colors, amount: string) => {
    setColors({
      ...colors,
      [color]: {
        ...colors[color],
        amount,
      },
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would save the refill data
    console.log({
      printerId,
      refillDate,
      colors,
    })
    // Reset form or show success message
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Registrar Abastecimento</CardTitle>
        <CardDescription>Registre as cores e quantidades abastecidas</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Data do Abastecimento</Label>
            <DatePicker date={refillDate} setDate={setRefillDate} />
          </div>

          <div className="space-y-4">
            <Label>Cores Abastecidas</Label>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox id="black" checked={colors.black.checked} onCheckedChange={() => handleColorCheck("black")} />
                <Label htmlFor="black" className="flex-1">
                  Preto
                </Label>
                {colors.black.checked && (
                  <Input
                    type="number"
                    placeholder="ml"
                    className="w-20"
                    value={colors.black.amount}
                    onChange={(e) => handleAmountChange("black", e.target.value)}
                  />
                )}
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="yellow"
                  checked={colors.yellow.checked}
                  onCheckedChange={() => handleColorCheck("yellow")}
                />
                <Label htmlFor="yellow" className="flex-1">
                  Amarelo
                </Label>
                {colors.yellow.checked && (
                  <Input
                    type="number"
                    placeholder="ml"
                    className="w-20"
                    value={colors.yellow.amount}
                    onChange={(e) => handleAmountChange("yellow", e.target.value)}
                  />
                )}
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox id="pink" checked={colors.pink.checked} onCheckedChange={() => handleColorCheck("pink")} />
                <Label htmlFor="pink" className="flex-1">
                  Rosa
                </Label>
                {colors.pink.checked && (
                  <Input
                    type="number"
                    placeholder="ml"
                    className="w-20"
                    value={colors.pink.amount}
                    onChange={(e) => handleAmountChange("pink", e.target.value)}
                  />
                )}
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox id="blue" checked={colors.blue.checked} onCheckedChange={() => handleColorCheck("blue")} />
                <Label htmlFor="blue" className="flex-1">
                  Azul
                </Label>
                {colors.blue.checked && (
                  <Input
                    type="number"
                    placeholder="ml"
                    className="w-20"
                    value={colors.blue.amount}
                    onChange={(e) => handleAmountChange("blue", e.target.value)}
                  />
                )}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Observações</Label>
            <Input id="notes" placeholder="Observações sobre o abastecimento" />
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" className="w-full">
            Registrar Abastecimento
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

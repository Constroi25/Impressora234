"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

export default function MonthlyUsageChart() {
  const chartRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!chartRef.current) return

    // In a real app, you would use a charting library like Chart.js
    // This is a placeholder to show how it would work
    const ctx = chartRef.current.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, chartRef.current.width, chartRef.current.height)

    // Draw placeholder chart
    const colors = {
      black: "#333",
      yellow: "#FFD700",
      pink: "#FF69B4",
      blue: "#1E90FF",
    }

    const data = [
      { color: "black", value: 250 },
      { color: "yellow", value: 120 },
      { color: "pink", value: 180 },
      { color: "blue", value: 150 },
    ]

    const barWidth = 40
    const spacing = 20
    const maxValue = Math.max(...data.map((d) => d.value))
    const scale = (chartRef.current.height - 60) / maxValue

    // Draw bars
    data.forEach((item, index) => {
      const x = 60 + index * (barWidth + spacing)
      const barHeight = item.value * scale
      const y = chartRef.current.height - 30 - barHeight

      ctx.fillStyle = colors[item.color as keyof typeof colors]
      ctx.fillRect(x, y, barWidth, barHeight)

      // Draw value
      ctx.fillStyle = "#000"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.fillText(`${item.value}ml`, x + barWidth / 2, y - 5)

      // Draw label
      ctx.fillText(item.color, x + barWidth / 2, chartRef.current.height - 10)
    })

    // Draw y-axis
    ctx.beginPath()
    ctx.moveTo(40, 10)
    ctx.lineTo(40, chartRef.current.height - 30)
    ctx.lineTo(chartRef.current.width - 20, chartRef.current.height - 30)
    ctx.stroke()

    // Draw y-axis labels
    ctx.textAlign = "right"
    ctx.fillText("0", 35, chartRef.current.height - 30)
    ctx.fillText(`${maxValue}`, 35, 20)
    ctx.fillText(`${Math.floor(maxValue / 2)}`, 35, chartRef.current.height - 30 - (maxValue / 2) * scale)
  }, [])

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-4 justify-between">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="month">Mês</Label>
            <Select defaultValue="april">
              <SelectTrigger id="month">
                <SelectValue placeholder="Selecione o mês" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="january">Janeiro</SelectItem>
                <SelectItem value="february">Fevereiro</SelectItem>
                <SelectItem value="march">Março</SelectItem>
                <SelectItem value="april">Abril</SelectItem>
                <SelectItem value="may">Maio</SelectItem>
                <SelectItem value="june">Junho</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="printer">Impressora</Label>
            <Select defaultValue="all">
              <SelectTrigger id="printer">
                <SelectValue placeholder="Selecione a impressora" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="1">L3210 - Sala Administrativo</SelectItem>
                <SelectItem value="2">L1250 - Sala Administrativo</SelectItem>
                <SelectItem value="3">L4260 - Financeiro</SelectItem>
                <SelectItem value="4">L3150 - Recursos Humanos</SelectItem>
                <SelectItem value="5">L355 - Recepção</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <Tabs defaultValue="bar">
        <TabsList className="grid grid-cols-2">
          <TabsTrigger value="bar">Gráfico de Barras</TabsTrigger>
          <TabsTrigger value="table">Tabela</TabsTrigger>
        </TabsList>
        <TabsContent value="bar">
          <Card>
            <CardContent className="p-6">
              <canvas ref={chartRef} width={600} height={300} className="w-full h-auto"></canvas>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="table">
          <Card>
            <CardContent className="p-6">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2">Cor</th>
                    <th className="text-right py-2">Quantidade (ml)</th>
                    <th className="text-right py-2">% do Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="py-2 flex items-center">
                      <div className="w-3 h-3 rounded-full bg-[#333] mr-2"></div>
                      Preto
                    </td>
                    <td className="text-right py-2">250</td>
                    <td className="text-right py-2">35.7%</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2 flex items-center">
                      <div className="w-3 h-3 rounded-full bg-[#FFD700] mr-2"></div>
                      Amarelo
                    </td>
                    <td className="text-right py-2">120</td>
                    <td className="text-right py-2">17.1%</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2 flex items-center">
                      <div className="w-3 h-3 rounded-full bg-[#FF69B4] mr-2"></div>
                      Rosa
                    </td>
                    <td className="text-right py-2">180</td>
                    <td className="text-right py-2">25.7%</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2 flex items-center">
                      <div className="w-3 h-3 rounded-full bg-[#1E90FF] mr-2"></div>
                      Azul
                    </td>
                    <td className="text-right py-2">150</td>
                    <td className="text-right py-2">21.4%</td>
                  </tr>
                  <tr>
                    <td className="py-2 font-bold">Total</td>
                    <td className="text-right py-2 font-bold">700</td>
                    <td className="text-right py-2 font-bold">100%</td>
                  </tr>
                </tbody>
              </table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
